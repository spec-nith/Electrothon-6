import aditya from "../assets/images/aditya.jpg.png";
import devang from "../assets/images/Devang.jpeg.png";
import gaurav from "../assets/images/gaurav.jpg.png";
import insha from "../assets/images/insha.jpg.png";
import kundan from "../assets/images/kundan.jpeg.png";
import rodrigo from "../assets/images/rodrigo.jpeg.png";
import bg from "../assets/images/background.png";
import bg2 from "../assets/images/bg2.jpg";
import bg3 from "../assets/images/bg3.jpg";
import headerimg from "../assets/images/headerimg.png";
import chamkadar from "../assets/images/chamkadar.png";
import man_demo from "../assets/images/man_demo.png";
import back_demo from "../assets/images/demo_back.png";
import phy_demo from "../assets/images/phy_demo.png";
import phy_l_demo from "../assets/images/phy_l_demo.png";
import l_demo from "../assets/images/demo_l.png";
import why_sponser from "../assets/images/why_sponser.png";
import why_sponserbg from "../assets/images/why_sponserbg.png";
import PrizeIcon1 from "../assets/images/PrizeIcon1.png";
import PrizeIcon2 from "../assets/images/PrizeIcon2.png";
import PrizeIcon3 from "../assets/images/PrizeIcon3.png";
import prizee from "../assets/images/prize.svg";
import support1 from "../assets/images/support1.png";
import support2 from "../assets/images/support2.svg";

import support4 from "../assets/images/support4.svg";
import support5 from "../assets/images/support5.svg";

import support7 from "../assets/images/support7.svg";
import support8 from "../assets/images/support8.svg";
import support9 from "../assets/images/support9.svg";
import support10 from "../assets/images/support10.svg";
import support11 from "../assets/images/support11.svg";
import support12 from "../assets/images/support12.svg";
import support13 from "../assets/images/support13.png";
import support14 from "../assets/images/support14.png";
import support15 from "../assets/images/support15.png";
import support16 from "../assets/images/support16.png";
import whysponser1 from "../assets/images/whysponsor1.png";
import whysponser2 from "../assets/images/whysponser2.png";
import whysponser3 from "../assets/images/whysponsor3.png";

import register from "../assets/images/register.svg";
import people from "../assets/images/people.svg";
import work from "../assets/images/work.svg";
import result from "../assets/images/result.svg";
import speclogo from "../assets/images/spec_logo.png";
import padmini from "../assets/images/bhucheti naga padmini.jpg";
import anirudh from "../assets/images/Anirudhattri.jpg";
import aman from "../assets/images/amanasrani.jpeg";
import adhishraya from "../assets/images/adhishraya.jpeg";
import abhi from "../assets/images/abhisheknautial.jpeg";
import abhishekraj from "../assets/images/abhishekraj.jpeg";
import aryan from "../assets/images/Aryanprasher.jpg";
import gauri from "../assets/images/gaurikaushal.jpeg";
import harshita from "../assets/images/harshitabhatia.jpeg";
import mukesh from "../assets/images/mukeshsinghrajput.jpeg";
import pratyaksh from "../assets/images/pratyaksh.jpeg";
import rishab from "../assets/images/rishab.jpeg";
import tanuj from "../assets/images/Tanuj.jpg";
import chaitnaya from "../assets/images/chaitanyakohlinew.jpg";

import polygon from "../assets/images/polygon.webp.png";
import replit from "../assets/images/Replit.webp.png";
import solana from "../assets/images/solana.webp.png";
import filecoin from "../assets/images/filecoin.webp.png";
import fire from "../assets/images/5ire.webp.png";
import ai from "../assets/images/ai.jpeg.jpg";
import ai3 from "../assets/images/ai3.jpeg";
import crypto from "../assets/images/crypto.jpeg.jpg";
import crypto2 from "../assets/images/crypto2.jpeg.jpg";
import finance from "../assets/images/finance.png";
import finance2 from "../assets/images/finance2.jpeg.jpg";
import game from "../assets/images/game.jpg";
import gaming from "../assets/images/gaming.jpeg.jpg";
import mobileapp1 from "../assets/images/mobileapps .png";
import mobileapp2 from "../assets/images/mobileapps.jpeg.jpg";
import dao from "../assets/images/dao.jpg";
import dao2 from "../assets/images/dao2.jpg";
import sport from "../assets/images/sport.png";

import blockchain1 from "../assets/images/blockchain1.jpeg";
import blockchain2 from "../assets/images/blockchain2.jpeg";
import Edtech1 from "../assets/images/Edtech1.jpg";
import Edtech2 from "../assets/images/Edtech2.jpeg";
import climate1 from "../assets/images/climate1.jpg";
import climate2 from "../assets/images/climate2.jpg";
import health1 from "../assets/images/health1.jpg";
import health2 from "../assets/images/health2.jpg";
import health3 from "../assets/images/health3.jpg";
import open_innovation1 from "../assets/images/open_innovation1.jpg";
import open_innovation2 from "../assets/images/open_innovation2.jpg";
import open_inno from "../assets/images/open_inno.jpg";

import padminimam from "../assets/images/padminimam.jpeg";

import foodtech1 from "../assets/images/foodtech1.jpg";
import foodtech2 from "../assets/images/foodtech2.jpg";

import gold from "../assets/images/gold.png";
import silver from "../assets/images/silver.png";
import bronze from "../assets/images/bronze.png";

// 2nd year team
import aahad from "../assets/images/aahad.jpg";
import abhijay from "../assets/images/Abhijay.jpg";
import akshansh from "../assets/images/Akshansh.jpeg";
import ananay from "../assets/images/ananay.jpg";
import aniket from "../assets/images/aniket.jpg";
import antriksh from "../assets/images/antriksh.jpg";
import arun from "../assets/images/arun.jpg";
import dikshant from "../assets/images/Dikshant.jpg";
import hammad from "../assets/images/hammad.jpg";
import jai from "../assets/images/jai.jpg";
import jayant from "../assets/images/jayant.jpg";
import khushbu from "../assets/images/khushbu.jpg";
import kunal from "../assets/images/kunal.jpg";
import lakshya from "../assets/images/Lakshya.jpg";
import nikita from "../assets/images/Nikita.jpg";
import nitin from "../assets/images/Nitin.jpg";
import parth from "../assets/images/Parth.jpg";
import pradhuman from "../assets/images/pradhuman.jpg";
import prakritipal from "../assets/images/prakritipal.png";
import priya from "../assets/images/Priya.jpg";
import priyanshi from "../assets/images/Priyanshi.jpg";
import priyanshu from "../assets/images/Priyanshu.png";
import rahul from "../assets/images/rahul.jpg";
import sania from "../assets/images/sania.jpg";
import utkarsh_chauhan from "../assets/images/utkarsh_chauhan.jpg";
import utkarsh_maurya from "../assets/images/Utkarsh_Maurya.jpg";

import magicbg from "../assets/images/magicbg.jpg";
import magicbg2 from "../assets/images/magicbg2.jpg";
import magicbg3 from "../assets/images/magicbg3.jpg";

import devfoliop from "./images/Devfolioppp.png";
import polygonp from "./images/polygonppp.png";
import replitp from "./images/Replitppp.png";
import orkes from "./images/orkes1ppp.png";


import taskade from "./images/taskadeppp.png";
import wolfram from "./images/wolframppp.png";
import hoverrobotix from "./images/HoverRobotixppp.png";

import healthcare_final1 from "./images/healthcare_final1.jpg";
import healthcare_final from "./images/healthcare_final.jpg";

// import sport from "../assets/images/sport.png"

import verbwire3 from "./images/verbwireppp.png";

import gg from "./images/gg.jpg";
import github from "./images/github.png";
import gfg from "./images/gfg.png";
import cake from "./images/cake.png";
import echo from "./images/echo.png";

import prizes from "./images/prizes.png";
import prizes2 from "./images/prizes2.png";
import prizesnew from "./images/prizesnew.png";
export {
  prizes2,
  prizesnew,
  prizes,
  gg,
  orkes,
  devfoliop,
  polygonp,
  replitp,
  magicbg,
  magicbg2,
  magicbg3,
  speclogo,
  people,
  work,
  result,
  register,
  bg,
  bg2,
  bg3,
  headerimg,
  chamkadar,
  man_demo,
  back_demo,
  phy_demo,
  phy_l_demo,
  l_demo,
  why_sponser,
  PrizeIcon1,
  PrizeIcon2,
  PrizeIcon3,
  prizee,
  support1,
  support2,
  support4,
  support5,
  support7,
  support8,
  support9,
  support10,
  support11,
  support12,
  support13,
  support14,
  support15,
  support16,
  why_sponserbg,
  whysponser1,
  whysponser2,
  whysponser3,
  aditya,
  insha,
  gaurav,
  rodrigo,
  devang,
  kundan,
  padmini,
  anirudh,
  aman,
  rishab,
  pratyaksh,
  gauri,
  abhi,
  padminimam,
  abhishekraj,
  chaitnaya,
  aryan,
  harshita,
  mukesh,
  adhishraya,
  tanuj,
  polygon,
  replit,
  solana,
  filecoin,
  fire,
  ai,
  ai3,
  crypto,
  crypto2,
  dao,
  dao2,
  finance,
  finance2,
  mobileapp1,
  mobileapp2,
  game,
  gaming,
  sport,
  arun,
  dikshant,
  aahad,
  abhijay,
  akshansh,
  ananay,
  aniket,
  antriksh,
  hammad,
  jai,
  jayant,
  khushbu,
  kunal,
  lakshya,
  nikita,
  nitin,
  parth,
  pradhuman,
  prakritipal,
  priya,
  priyanshi,
  priyanshu,
  rahul,
  sania,
  utkarsh_chauhan,
  utkarsh_maurya,
  blockchain1,
  blockchain2,
  climate1,
  climate2,
  health1,
  health2,
  health3,
  open_innovation1,
  open_innovation2,
  Edtech1,
  Edtech2,
  foodtech1,
  foodtech2,
  gold,
  silver,
  bronze,
  healthcare_final,
  healthcare_final1,
  open_inno,
  hoverrobotix,
  wolfram,
  taskade,
  verbwire3,
  github,
  gfg,
  cake,
  echo,
};
